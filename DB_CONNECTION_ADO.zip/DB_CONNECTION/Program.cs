﻿using System;
using MyApp.BAL;
using MyApp.Models;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Host=localhost;Username=postgres;Password=sar@123;Database=user_management";
            AdminBAL adminBal = new AdminBAL(connectionString);

            // Adding an admin
            Admin newAdmin = new Admin
            {
                Username = "adminuser",
                Password = "adminpassword123"  // Hash the password before storing in a real application
            };
            adminBal.AddAdmin(newAdmin);
            Console.WriteLine("Admin added successfully!");

            // Deleting an admin
            adminBal.DeleteAdmin("adminuser");
            Console.WriteLine("Admin deleted successfully!");
        }
    }
}
