﻿using MyApp.DAL;
using MyApp.Models;
using Npgsql;

namespace MyApp.BAL
{
    public class AdminBAL
    {
        private readonly DatabaseExecutor _databaseExecutor;

        public AdminBAL(string connectionString)
        {
            _databaseExecutor = new DatabaseExecutor(connectionString);
        }

        public void AddAdmin(Admin admin)
        {
            string query = "INSERT INTO users (username, password) VALUES (@username, @password)";
            var parameters = new NpgsqlParameter[]
            {
                new NpgsqlParameter("@username", admin.Username),
                new NpgsqlParameter("@password", admin.Password)  // Ensure password is hashed before storing
            };
            _databaseExecutor.ExecuteNonQuery(query, parameters);
        }

        public void DeleteAdmin(string username)
        {
            string query = "DELETE FROM users WHERE username = @username";
            var parameters = new NpgsqlParameter[]
            {
                new NpgsqlParameter("@username", username)
            };
            _databaseExecutor.ExecuteNonQuery(query, parameters);
        }
    }
}
